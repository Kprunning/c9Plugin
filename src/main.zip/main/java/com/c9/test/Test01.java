package com.c9.test;

import com.c9.jjc.service.impl.JJCServiceImpl;

public class Test01 {
    public static void main(String[] args) {
//        OpenC9 c9 = new OpenC9();
//        c9.start();
        for (int i = 0; i < 5; i++) {
            new JJCServiceImpl().racing();
        }

    }
}


