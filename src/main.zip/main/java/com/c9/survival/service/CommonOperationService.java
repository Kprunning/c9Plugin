package com.c9.survival.service;

public interface CommonOperationService {

	void exit();

	void acceptInviting();

	void shutdown();

	
}
