package com.c9.survival.service;

public interface LoginService {

	void start();

	void switchSecondRole();

}
