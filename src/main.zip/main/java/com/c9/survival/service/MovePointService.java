package com.c9.survival.service;

public interface MovePointService {

	void moveShengCun1();

}
