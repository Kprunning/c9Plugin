package com.c9.jjc.service.impl;

import com.c9.common.base.Base;
import com.c9.common.base.ColorHelper;
import com.c9.common.base.LoadProperty;
import com.c9.common.base.Mouse;
import com.c9.common.rpc.client.Client;
import com.c9.jjc.service.JJCService;
import org.springframework.stereotype.Service;

import java.awt.event.KeyEvent;
import java.net.InetSocketAddress;
import java.util.Properties;
import java.util.Random;

@Service
public class JJCServiceImpl extends Base implements JJCService {
    // 加载JJC坐标文件
    private static Properties jjcPro = new LoadProperty().loadPro("src/main/resources/jjc/jjc.properties");
    // 加载RPC文件
    private static Properties rpcPro = new LoadProperty().loadPro("src/main/resources/jjc/jjc.properties");
    // 获取主从机
    private String machineRole = jjcPro.getProperty("机器");
    // 获取主从IP
    private String masterIP = rpcPro.getProperty("masterIP");
    private String slaveIP = rpcPro.getProperty("slaveIP");
    // 获取主从端口
    private Integer mPort = Integer.parseInt(rpcPro.getProperty("masterPort"));
    private Integer sPort = Integer.parseInt(rpcPro.getProperty("slavePort"));


    /**
     * 竞技场开始方法
     */
    public void start() throws ClassNotFoundException {
        JJCServiceImpl jjc = new JJCServiceImpl();
        JJCService jjcSlave = null;
        // 房间准备,进入游戏
        if(machineRole.equals("主机")) {
            // 通过RPC调用从机准备(主机调用从机端口)
            jjcSlave = Client.getRemoteProxyObj(Class.forName("com.c9.jjc.service.JJCService"), new InetSocketAddress(slaveIP, sPort));
            while(true){
                // 主机准备,等待从机确认
                jjc.ready();
                jjcSlave.ready();

                // 主机开始执行跳水
                for (int i = 0; i < 4; i++) {
                    jjc.racing();
                }
                // 通知从机进行跳水
                for (int i = 0; i < 5; i++) {
                    jjcSlave.racing();
                }
            }
        }

    }

    /**
     * 大厅界面,主机勾选自动开始,从机点准备直接进入地图
     */
    public void ready(){
        // 获取配置文件中机器角色,选择执行策略
        if(machineRole.equals("主机")){
            // 主机(房主)角度编程
            // 大厅界面,勾选右下角自动开始
            robot.delay(10000 + lTimeRandom);
            Mouse.moveStringLocation(jjcPro.getProperty("自动开始"));
            robot.delay(1000 + sTimeRandom);
            Mouse.clickLeft();
            // 通知从机准备有两种方法:从机延时准备,RPC远程调用

            // 载入画面等待
            robot.delay(20000 + lTimeRandom);
        }else{
            // 从机(队员角度编程)
            // 这里采用从机延时准备
            robot.delay(5000 + lTimeRandom);
            Mouse.moveStringLocation(jjcPro.getProperty("开始or就绪"));
            robot.delay(1000 + sTimeRandom);
            Mouse.clickLeft();

            // 载入画面等待
            robot.delay(12000 + lTimeRandom);
        }

        // 等待队员点准备进入游戏
        // 检测主机是否更换,观察队员界面

    }

    /**
     * 进入沃特福德竞赛地图
     * 跳水程序,不分主从机,
     * 主机设定为一定时间后执行,从机接受主机执行完毕信号后开始执行
     */
    public void racing(){
        robot.delay(2000 + lTimeRandom);
        // 开始执行跳水
        // 按下w键控制角色前进,移动到木桥中央
        robot.keyPress(KeyEvent.VK_W);
        robot.delay(2300 + sTimeRandom);

/*
        while(true){
            // 每100ms检测一次,左侧坐标的颜色,来确认是否走到了可以跳水的位置
            robot.delay(50);
            int leftRiver = ColorHelper.getRGBBySC(pro.getProperty("河流左"));
            System.out.println(leftRiver);
            int rightRiver = ColorHelper.getRGBBySC(pro.getProperty("河流右"));
            // 因为颜色很难保证完全一致,所以差距范围在10000内都认定为同一种颜色
            int leftBound = Math.abs(leftRiver - Integer.parseInt(pro.getProperty("河流颜色")));
            System.out.println(leftBound);
            int rightBound = Math.abs(rightRiver - Integer.parseInt(pro.getProperty("河流颜色")));
            if(leftBound < 10000 || rightBound < 10000){
                // 如果颜色在误差范围内,则认为河流出现,跳出循环
                break;
            }
        }
*/
        robot.keyRelease(KeyEvent.VK_W);
        // 按下a或w键控制角色从两侧跳水
        int i = new Random().nextInt(2); // 获得随机数0或1
        int ad = KeyEvent.VK_A;
        if(i == 0){
            ad = KeyEvent.VK_D;
        }
        robot.keyPress(ad);
        robot.delay(2000 + sTimeRandom);
        robot.keyRelease(ad);

        // 角色已经跳水,等待重生,设定等待时间为4s
        robot.delay(7000 + lTimeRandom);
    }


    /**
     * 改进:不作为跳水次数依据,而是作为辅助检测进行状况,进行程序报错和终止
     * @param ballNum 输入要检查球的编号
     */
    public void checkBallColor(int ballNum){
        String ballName = "球" + ballNum;
        // 加载属性文件
        Properties pro = new LoadProperty().loadPro("resources/jjc/jjc.properties");
        // 获取小球坐标
        String ballLocation = pro.getProperty(ballName);
        // 根据小球坐标检查小球颜色
        int color = ColorHelper.getRGBBySC(ballLocation);
        int abs = Math.abs(color - Integer.parseInt(pro.getProperty("")));
        // 判断小球颜色是否和配置文件相符
        if(abs > 10000){
            // 误差大于10000颜色异常
            System.out.println("脚本执行异常,请注意!");
            // 出现异常进行QQ通知和关机处理
            //Runtime.getRuntime().exec("shutdown /s /t 60");
        }
    }

    /**
     * 测试rpc效果
     */
    public void sayHi(String name){
        System.out.println("Hello " + name + " !");

    }
}
